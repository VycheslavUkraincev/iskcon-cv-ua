const { chromium } = require(process.env.T+'/node_modules/playwright');const {PNG}=require(process.env.T+'/node_modules/pngjs');
const B='http://127.0.0.1:8765/iskcon-cv-ua/',OLD='http://127.0.0.1:8782/iskcon-cv-ua/',S=process.env.HOME+'/scratch/m/s/';
const CSS='.avatar-widget,.avatar-card{display:none!important}*{animation:none!important;transition:none!important}.reveal{opacity:1!important;transform:none!important}';
async function full(br,u,w){const c=await br.newContext({viewport:{width:w,height:900},reducedMotion:'reduce'});const p=await c.newPage();await p.goto(u,{waitUntil:'load'});await p.addStyleTag({content:CSS});await p.evaluate(async()=>{for(let y=0;y<document.documentElement.scrollHeight;y+=400){scrollTo(0,y);await new Promise(r=>setTimeout(r,100))}scrollTo(0,0)});await p.waitForFunction(()=>[...document.images].every(i=>i.complete)).catch(()=>{});await p.waitForTimeout(400);const b=PNG.sync.read(await p.screenshot({fullPage:true}));await c.close();return b}
function diff(a,b){if(a.width!==b.width||a.height!==b.height)return `size ${a.width}x${a.height} vs ${b.width}x${b.height}`;let n=0;for(let i=0;i<a.data.length;i+=4)if(a.data[i]!==b.data[i]||a.data[i+1]!==b.data[i+1]||a.data[i+2]!==b.data[i+2])n++;return String(n)}
(async()=>{const br=await chromium.launch({channel:'chrome'});
 for(const l of ['uk','en','ro']){const c=await br.newContext({viewport:{width:1440,height:900}});const p=await c.newPage();await p.goto(B+'courses/?lang='+l,{waitUntil:'load'});await p.waitForTimeout(500);
  const btns=await p.$$('[data-course-form]');
  for(const b of btns){const course=await b.evaluate(e=>e.closest('[data-course]').dataset.course);const txt=(await b.textContent()).trim();const attrs=await b.evaluate(e=>[e.target,e.rel].join(' '));
   const [np]=await Promise.all([c.waitForEvent('page'),b.click()]);await np.waitForLoadState('domcontentloaded');await np.waitForTimeout(1500);console.log(l,'card',course,'| btn:',txt,'|',attrs,'| opened title:',await np.title());await np.close()}
  // загальна кнопка → якір
  await p.evaluate(()=>scrollTo(0,document.body.scrollHeight));await p.click('[data-form="courses"]');await p.waitForTimeout(800);
  console.log(l,'general btn ->',await p.evaluate(()=>location.href.split('/').pop()+' cardsTop='+Math.round(document.getElementById('courses-list').getBoundingClientRect().top)));
  const q=await c.newPage();await q.goto(B+'food/?lang='+l,{waitUntil:'load'});await q.waitForTimeout(400);const v=await q.$('[data-form="ffl-volunteer"]');const vt=(await v.textContent()).trim();
  const [np]=await Promise.all([c.waitForEvent('page'),v.click()]);await np.waitForLoadState('domcontentloaded');await np.waitForTimeout(1500);console.log(l,'food volunteer | btn:',vt,'| opened title:',await np.title());await c.close()}
 for(const [n,u] of [['home',''],['donation','donation/'],['404','404.html']])for(const w of [1440,375])console.log('regr',n,w,diff(await full(br,B+u,w),await full(br,OLD+u,w)));
 await br.close()})();
