const { chromium } = require(process.env.T+'/node_modules/playwright');
(async()=>{const br=await chromium.launch({channel:'chrome'});const c=await br.newContext();const p=await c.newPage();const P='https://vycheslavukraincev.github.io/iskcon-mockup-v2-preview/';
await p.goto(P+'courses/',{waitUntil:'load'});console.log(await p.$$eval('[data-course-form]',a=>a.map(x=>x.href.slice(36,60)+' '+x.target)));
await p.goto(P+'food/',{waitUntil:'load'});console.log(await p.$eval('[data-form="ffl-volunteer"]',a=>a.href.slice(36,60)+' '+a.target));
await p.goto(P,{waitUntil:'load'});console.log('logo',await p.$eval('.brand img',i=>i.naturalWidth>0),'avatar',await p.$eval('#avatarChar',e=>e.getBoundingClientRect().width));await br.close()})();
