# Скрипты мастер-задания (23.10.2026)

Окружение: `export T=~/scratch/tools` (playwright, pngjs, sharp, lighthouse, potrace). Серверы: 8765 — сайт без gzip (`python3 -m http.server` из папки с симлинком `iskcon-cv-ua` → репозиторий), 8766 — `../gz.js` (gzip, для Lighthouse). Базу для сравнения делать так: `git archive <коммит> index.html courses.html courses food.html food donation.html donation 404.html assets favicon.ico | tar -x -C <папка>/iskcon-cv-ua` и поднять отдельный сервер на свободном порту (8768 бывает занят).

| Файл | Что делает |
|---|---|
| `inv.py <корень сайта> <out.json>` | побайтный эталон инвариантов: платёжные ссылки, tel/Viber/WhatsApp/Telegram, IBAN, ЄДРПОУ, телефоны в тексте, все времена (расписание), sha256 QR. Сравнивать два json до/после |
| `preview.sh "<метка>"` | обновить превью из `mockup-v2` по процедуре HANDOFF §2 и дождаться сборки Pages. Путь к клону превью внутри скрипта — временный; если клона нет, `git clone` превью-репо и поправить путь |
| `cyr.js [base] [widths]` | кириллица в EN/RO + ошибки консоли на 5 страницах |
| `av.js`, `av2.js` | аватар: 0 px движения при скролле/hover/старте видео, перекрытия, модалка поверх, reduced-motion |
| `shots.js <base> <out> [widths] [pages]` | полностраничные JPG |
| `sect.js <url> <selector> <out-prefix> [widths] [langs]` | скриншот секции + кириллица в ней |
| `lh.sh <port> <label> [runs]` | Lighthouse mobile по 4 страницам |
| `audit.js` | аудит мелочей: горизонтальный скролл, обрезка, фокус, цели касания, крупные растры |
| `hdr2.js` | шапка: помещается ли бренд рядом с кнопками языков (320–768) |
| `snap.js <url> <out.png> [width]` | быстрый снимок страницы |
| `qrbuild.js <in.png> <out.png>` | пересборка QR из точной матрицы модулей (1-битная PNG, исходное белое поле); печатает версию, «нечистые» модули, вес и содержимое |
| `cidecode.swift <png…>` | второй, независимый декодер QR (macOS CoreImage): `swift cidecode.swift <файлы>` |
| `jsq.js <png…>` | декод jsQR, сырые байты в hex |
| `hero.js <base> <out-prefix>` | hero `/food` на 1440/375 + размеры фото/текста |
| `regr.js [pages]` | попиксельная регрессия база (8769) ↔ текущее (8765), 1440/768/375 |
| `avov.js <base> [widths]` | главная: шаг скролла 20 px, считает позиции, где аватар/облачко перекрывают текст `#schedule` или кнопки |
| `yieldrate.js <base>` | доля позиций скролла (375), где аватар погашен (`.av-yield`), и состояние при загрузке |
| `cal.js <base>` | клик-тест «Додати в календар» (popup на calendar.google.com, параметры, 0 загрузок) + тихая ссылка `.ics` |
| `anchors.js <base>` | внешний переход на `страница#id` (18 якорей × 375/1440 × UK/EN): цель под шапкой |
| `avshot.js <base> <out.jpg>` | снимок 375 с рядами 15:15/16:00 в углу аватара |
| `textdiff.py <base-root> <new-root>` | дифф текстовых узлов страниц и строк словаря |
| `wigscan.py` | механическая проверка по правилам Vercel web-design-guidelines (`файл:строка`) |
| `focusall.js <base>` | видимый фокус карты Google с клавиатуры: карта не загружена / загружена, Shift+Tab, клик мышью |
| `taps.js <base>` | размеры целей касания: кнопки языков, ссылки-действия |
| `secdiff.js <page> <width> [rows]` | высоты секций база ↔ текущее и элементы в заданных строках диффа |
| `ringshot2.js <base> <out.jpg>` | скриншот обводки фокуса карты |
